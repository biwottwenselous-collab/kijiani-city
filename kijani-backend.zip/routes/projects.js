const express = require('express');
const router = express.Router();
const Project = require('../models/Project');
const auth = require('../middleware/auth');

// Get all projects (public minimal info)
router.get('/', async (req, res) => {
  const list = await Project.findAll({ attributes: ['id','title','description'] });
  res.json(list);
});

// Create project
router.post('/', auth, async (req, res) => {
  const { title, description, metadata } = req.body;
  if (!title) return res.status(400).json({ message: 'Missing title' });
  const project = await Project.create({ title, description, metadata, ownerId: req.user.id });
  res.status(201).json(project);
});

// Get single project
router.get('/:id', async (req, res) => {
  const project = await Project.findByPk(req.params.id);
  if (!project) return res.status(404).json({ message: 'Not found' });
  res.json(project);
});

// Update (owner only)
router.put('/:id', auth, async (req, res) => {
  const project = await Project.findByPk(req.params.id);
  if (!project) return res.status(404).json({ message: 'Not found' });
  if (project.ownerId !== req.user.id && req.user.role !== 'admin') return res.status(403).json({ message: 'Forbidden' });
  const { title, description, metadata } = req.body;
  project.title = title ?? project.title;
  project.description = description ?? project.description;
  project.metadata = metadata ?? project.metadata;
  await project.save();
  res.json(project);
});

// Delete (owner or admin)
router.delete('/:id', auth, async (req, res) => {
  const project = await Project.findByPk(req.params.id);
  if (!project) return res.status(404).json({ message: 'Not found' });
  if (project.ownerId !== req.user.id && req.user.role !== 'admin') return res.status(403).json({ message: 'Forbidden' });
  await project.destroy();
  res.json({ message: 'Deleted' });
});

module.exports = router;
