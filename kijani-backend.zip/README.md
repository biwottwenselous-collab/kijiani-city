# Kijani Backend (Node.js + Express)

## Overview
This repository contains a simple REST API for the Kijani project using Node.js, Express and PostgreSQL (via Sequelize). It supports user registration/login (JWT) and a simple Project resource with ownership.

## Quick start
1. Create a new folder and add the files from this document (preserving file names and folder structure).
2. Copy `.env.example` to `.env` and fill values.
3. Ensure PostgreSQL is running and `DATABASE_URL` points to a valid DB.
4. Install dependencies:

```bash
npm install
```

5. Start the app:

```bash
npm run dev
```

6. API endpoints:
- `POST /api/auth/register` {name,email,password}
- `POST /api/auth/login` {email,password} -> returns `{token}`
- `GET /api/projects`
- `POST /api/projects` (auth)
- `GET /api/projects/:id`
- `PUT /api/projects/:id` (auth / owner)
- `DELETE /api/projects/:id` (auth / owner)

## Notes
- This is a minimal starting point. Add validation, request rate-limiting, logging, proper error handling, tests, migrations, and HTTPS in production.
- For cloud deployment consider Dockerizing and using a managed database.
